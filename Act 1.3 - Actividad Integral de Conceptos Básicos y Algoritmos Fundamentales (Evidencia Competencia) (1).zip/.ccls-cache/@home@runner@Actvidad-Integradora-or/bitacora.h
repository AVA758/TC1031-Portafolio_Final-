#ifndef _BITACORA_H_
#define _BITACORA_H_

#include <vector>
#include <fstream>
#include <stdexcept>
#include <string>
#include "Registro.h"

class Bitacora {

  private:
    std::vector<Registro> listaRegistros;
    // DLinkedList<Registro> listaRegistros;
    
    void merge(std::vector<T> &A, int low, int m, int high, unsigned int &compara);

  public:
    Bitacora();
    Bitacora(std::string "bitacora.txt");
    ~Bitacora();
    void print();
    // Ordenamiento
    void bubbleSort();
    void mergeSort();
    // Busqueda

};



#endif  // _BITACORA_H_