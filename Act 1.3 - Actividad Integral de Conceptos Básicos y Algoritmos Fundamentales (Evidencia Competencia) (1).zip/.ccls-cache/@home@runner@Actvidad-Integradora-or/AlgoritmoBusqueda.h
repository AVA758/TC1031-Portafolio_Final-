#ifndef ALGORITMOBUSQUEDA_H_
#define ALGORITMOBUSQUEDA_H_


#include <iostream>
#include <vector>
#include <chrono>
#include "AlgoritmoSort.h"

using std::cout;
using std::cin;
using std::endl;
using std::vector;

template <class T>
class AlgoritmoBusqueda {
  private:
    
  public:
    AlgoritmoBusqueda();
   
  int busquedaBinaria(std::vector<int> &listaRegistro, int key, unsigned int &compara);
};

template<class T>
AlgoritmoBusqueda<T>::AlgoritmoBusqueda() {
}

// Busqueda Binaria
// Algoritmo de buscamiento que funciona teniendo una llave y comparandola con las dos mitades del arreglo.
// Complejidad: O(log n) (peor caso)
template <class T>
int AlgoritmoBusqueda<T>::busquedaBinaria(std::vector<int> &listaRegistro, int key, unsigned int &compara) {
  int low = 0;
  int high = (int)listaRegistro.size()-1;
  int mid = 0;
  while(low <= high) {
    mid = (low + high)/2;
    compara += 1;
    if (key == listaRegistro[mid]) {
      return mid;
    } else if (key < listaRegistro[mid]) {
      high = mid - 1;
    } else {
      low = mid + 1;
    }
  }
  return -1;
}

#endif