#ifndef _ALGORITMOSORT_H_
#define _ALGORITMOSORT_H_

#include <iostream>
#include <vector>
#include <algorithm>
#include "AlgoritmoBusqueda.h"
#include "Bitacora.h"
#include "Registro.h"

template <class T>
class AlgoritmoSort {
  private:
    void merge(std::vector<T> &A, int low, int m, int high, unsigned int &compara);

  public:
    AlgoritmoSort();
    void printVector(std::vector<T> A);
    void ordenaBurbuja(std::vector<T> &A, int n, unsigned int &compara, unsigned int &swap);
    void ordenaMerge(std::vector<T> &A, int low, int high, unsigned int &compara);

 
};

template<class T>
AlgoritmoSort<T>::AlgoritmoSort() {
  
}

// Imprime Vector
// Imprime en pantalla los elementos dle vector ordenado.
// Complejidad: O(n)
template<class T>
void AlgoritmoSort<T>::printVector(std::vector<T> A) {
    for(int i = 0; i < (int)A.size(); i++) {
      std::cout << A[i] << " ";
    }
    std::cout << std::endl;
}

// Ordena Burbuja
// Ordenar vector en forma ascendente comparando elementos adyacentes y cambiandolos de lugar, como burbujas. 
// Complejidad: O(n^2) (peor caso)
template <class T>
void AlgoritmoSort<T>::ordenaBurbuja(std::vector<T> &listaRegistros, int n, unsigned int &comparaciones, unsigned int &swaps){
  
  for(int i = 0; i < n-1; i++){
    for (int j = 0; j < n-i-1; j++){
      comparaciones++;
      if(listaRegistros[j] > listaRegistros[j+1]){
      std::swap(listaRegistros[j], listaRegistros[j+1]);
      swaps++;
      }
    }
  }
}

// Ordena Merge
// Ordena arreglo en forma ascendente recursivamente dividiendo el problema en subproblemas de menor tamano.
// Complejidad: O(n log n) (peor caso)
template <class T>
void AlgoritmoSort<T>::ordenaMerge(std::vector<T> &listaRegistros, int low, int high, unsigned int &compara) {
  if (low < high) {
    // encontrar el punto medio
    int m = low + (high - low) / 2;
    // Ordenar dos mitades
    ordenaMerge(listaRegistros, low, m, compara);
    ordenaMerge(listaRegistros, m+1, high, compara);
    // Fusionar ambas mitades
    merge(listaRegistros, low, m, high, compara);
  }
}

// Merge
// Parte llamada recursivamente del metodo Merge Sort
// Complejidad: O(n)
template <class T>
void AlgoritmoSort<T>::merge(std::vector<T> &listaRegistros, int low, int m, int high, unsigned int &compara) {
  int i, j, k;
  int n1 = m - low + 1;
  int n2 = high - m;
  // crear los vectores auxiliares L y R
  std::vector<T> L(n1);
  std::vector<T> R(n2);
  for (i = 0; i < n1; i++) L[i] = listaRegistros[low + i];
  for (j = 0; j < n2; j++) R[j] = listaRegistros[m + 1 + j];
  // Fusionar los vectores auxiliares Ly R ordenados
  i = j = 0;
  k = low;
  while (i<n1 && j<n2) {
    compara++;
    if (L[i] <= R[j]){
      listaRegistros[k]=L[i];
      i++;
    }
    else{
      listaRegistros[k] = R[j];
      j++;
    }
    k++;
  }
  // Copia los elementos restantes
  while (i < n1){
    listaRegistros[k] = L[i];
    i++;
    k++;
  }
  while (j < n2){
    listaRegistros[k] = R[j];
    j++;
    k++;
  }
}


#endif