#include "Bitacora.h"


Bitacora::Bitacora() {

}

Bitacora::Bitacora(std::string "bitacora.txt") {
  std::string month, day, hours, minutes, seconds, ipAdd, port, error;
  std::ifstream file("bitacora.txt");
  if (!file.good()) {
    file.close();
    throw std::invalid_argument("File not found");
  }
  else {
    while (!file.eof()) {
        std::getline(file, month, ' ');
        std::getline(file, day, ' ');
        std::getline(file, hours, ':');
        std::getline(file, minutes, ':');
        std::getline(file, seconds, ' ');
        std::getline(file, ipAdd, ':');
        std::getline(file, port, ' ');
        std::getline(file, error);
        // Crear un objeto de la clase Registro
        Registro tmpRegistro(month, day, hours, minutes, seconds, ipAdd, port, error);
        // Agregar al vector de regisrros
        listaRegistros.push_back(tmpRegistro);
      }
    file.close();
  }
}

Bitacora::~Bitacora() {
  listaRegistros.clear();
}

void Bitacora::print() {
  std::cout << "La bitacora contiene lo siguiente:" << std::endl;
  for (int i=0; i < listaRegistros.size(); i++)
    std::cout << listaRegistros[i] << std::endl;
}
// Es solo un ehemolo de ordenamiento, 
// Se requiere en act 1.3 un algoritmo más eficiente
// quicksort o mergesort
int comparaciones;
int swaps = 0;

void Bitacora::bubbleSort() {
  int i, j;
  int n = listaRegistros.size();
  Registro tmp;
  for (i = 0; i < n-1; i++) {
    for (j = 0; j < n-i-1; j++) {
      comparaciones++;
      if (listaRegistros[j] > listaRegistros[j+1]){
        /**
        tmp = listaRegistros[j];
        listaRegistros[j] = listaRegistros[j+1];
        listaRegistros[j+1] = tmp;
        **/
        std::swap(listaRegistros[j], listaRegistros[j+1]);
        swaps++;
      }
    }
  }
}

void Bitacora::mergeSort(){
  compraciones = 0;
  int low = 0;
  int high = listaRegitros.size()-1;
   if (low < high) {
    // encontrar el punto medio
    int m = low + (high - low) / 2;
    // Ordenar dos mitades
    ordenaMerge(listaRegistros, low, m, comparaciones);
    ordenaMerge(listaRegistros, m+1, high, comparaciones);
    // Fusionar ambas mitades
    merge(listaRegistros, low, m, high, comparaciones);
  }
}

void Bitacora::merge(std::vector &listaRegistros, int low, int m, int high, int &comparaciones){
  int i, j, k;
  int n1 = m - low + 1;
  int n2 = high - m;
  // crear los vectores auxiliares L y R
  std::vector<T> L(n1);
  std::vector<T> R(n2);
  for (i = 0; i < n1; i++) L[i] = listaRegistros[low + i];
  for (j = 0; j < n2; j++) R[j] = listaRegistros[m + 1 + j];
  // Fusionar los vectores auxiliares Ly R ordenados
  i = j = 0;
  k = low;
  while (i<n1 && j<n2) {
    compara++;
    if (L[i] <= R[j]){
      listaRegistros[k]=L[i];
      i++;
    }
    else{
      listaRegistros[k] = R[j];
      j++;
    }
    k++;
  }
  // Copia los elementos restantes
  while (i < n1){
    listaRegistros[k] = L[i];
    i++;
    k++;
  }
  while (j < n2){
    listaRegistros[k] = R[j];
    j++;
    k++;
  }
}


// Falta implementar busqueda binaria
Bitacora::busquedaBinaria(Registro key) {
  int low = 0;
  int high = (int)listaRegistros.size()-1;
  int mid = 0;
  while(low <= high) {
    mid = (low + high)/2;
    compara += 1;
    if (key == listaRegistros[mid]) {
      return mid;
    } else if (key < listaRegistros[mid]) {
      high = mid - 1;
    } else {
      low = mid + 1;
    }
  }
  return -1;
  
}